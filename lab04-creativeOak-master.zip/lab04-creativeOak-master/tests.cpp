/*
  Copyright (c) 2020
  Swarthmore College Computer Science Department, Swarthmore PA
  J. Brody, A. Danner, M. Gagne, L. Meeden, Z. Palmer, A. Soni, M. Wehar
  Distributed as course material for Fall 2020
  CPSC 035: Data Structures and Algorithms
  https://tinyurl.com/yyr8mdoh
*/

#include <UnitTest++/UnitTest++.h>
#include <iostream>

#include "mergeSort.h"

using namespace std;

TEST(threeElements) {
  // Create a static array containing the numbers 4, 8, 6.
  int array[3] = {4, 8, 6};

  mergeSort(array, 3);

  CHECK_EQUAL(4, array[0]);
  CHECK_EQUAL(6, array[1]);
  CHECK_EQUAL(8, array[2]);
}

//tests mergeSort on an array in reverse order
TEST(reverseSorted) {
  int size = 20;
  // Create a dynamically-allocated array
  int *array = new int[size];
  for (int i = 0; i < size; i++) {
    array[i] = size - 1 - i;
  }

  mergeSort(array, size);

  for (int i = 0; i < size; i++) {
    CHECK_EQUAL(i, array[i]);
  }
  // de-allocate array
  delete[] array;
  array = nullptr;
}

// TODO: put your other tests here
// TODO: rename the test
// TODO: create an array, and call mergeSort on it
// TODO: use CHECK_EQUAL to test whether mergeSort worked
// TODO: write a comment describing your test

//tests mergeSort on a single element set
TEST(SingleElement) {
  int* array = new int[1];
  array[0] = 5;
  mergeSort(array, 1);
    
  CHECK_EQUAL(5, array[0]); 

  delete[] array;
  array = nullptr;
  
}

//tests mergeSort on a sorted set
TEST(SortedArray) {
  int array[5] = {1, 2, 3, 4, 5};

  mergeSort(array, 5);

  for (int i = 0; i < 5; i++) {
    CHECK_EQUAL(i + 1, array[i]); 
  }

}

//This test tests mergeSort on an empty set
TEST(EmptyList) {
  int array[] = {}; 
  mergeSort(array, 0);
  CHECK_EQUAL(NULL, array[0]);
}

//tests mergeSort on a set with multiple duplicates
TEST(duplicates) {
  //create an array with duplicates
  int array[15] = {0,1,2,3,4,5,6,6,0,0,6,6,1,5,6};

  mergeSort(array, 15);

  //checks if first 3 elements of sorted array are 0
  for(int i=0;i<3;i++){
    CHECK_EQUAL(0, array[i]);
  }
  //checks if last 5 elements are 6
  for(int i=10;i<15;i++){
    CHECK_EQUAL(6, array[i]);
  } 
}

//tests mergeSort on a set with elements approaching a midpoint from opposite directions
TEST(midEnd) {
  //create an array with elements approaching the midpoint
  int array[10] = {0,9,1,8,2,7,3,6,4,5};

  mergeSort(array, 10); 

  //checks if sorted
  for(int i=0;i<10;i++){
    CHECK_EQUAL(i, array[i]);
  }
}

/* no need to modify main */
int main() {
  return UnitTest::RunAllTests();
}
