/*
  Copyright (c) 2020
  Swarthmore College Computer Science Department, Swarthmore PA
  J. Brody, A. Danner, M. Gagne, L. Meeden, Z. Palmer, A. Soni, M. Wehar
  Distributed as course material for Fall 2020
  CPSC 035: Data Structures and Algorithms
  https://tinyurl.com/yyr8mdoh
*/

#include <iostream>
#include <string>
#include <utility>

#include "adts/list.h"
#include "asciimationFunctions.h"
#include "linkedList.h"

using namespace std;

int main() {
    // TODO: write any tests you want here; this is your sandbox
    LinkedList<int>* list = new LinkedList<int>();
    /* for (int i = 0; i < size; i++) {
        list->insertLast(i * 2);
    } */
   if (list->isEmpty()){
     cout<<"Empty";
   }
   int len = list->getSize();
   cout<<"Initial List length: "<<len<<endl;
   //add 10 first and print set
   for(int i=0;i<10;i++){
     list->insertFirst(i);
   }
   for(int i=0;i<10;i++){
     int item = list->get(i);
     cout << item <<endl;
   }
   cout<<"New List length: "<<list->getSize()<<endl;

   //add 5 last and print set
   for(int i=0;i<5;i++){
     list->insertLast(i);
   }
  for(int i=0;i<15;i++){
     int item = list->get(i);
     cout <<item <<endl;
   }
   cout<<"New List length: "<<list->getSize()<<endl;

   //get first and last
   cout<<"First element: "<<list->getFirst()<<endl<<"Last element: "<<list->getLast();
   
   //Removes first node and decreases size
   int Removed = list->removeFirst(); 
  for(int i=0;i<14;i++){
     int item = list->get(i);
     cout <<item <<endl;
   }
   cout<<"New List length: "<<list->getSize()<<endl;
   cout<<"Removed is: "<<Removed<<endl;

  //Removes last node and decreases size
   int Removed2 = list->removeLast(); 
  for(int i=0;i<13;i++){
     int item = list->get(i);
     cout <<item <<endl;
   }
   cout<<"New List length: "<<list->getSize()<<endl;
   cout<<"Removed is: "<<Removed2<<endl;

   delete list;


    return 0;
}
