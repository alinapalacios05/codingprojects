/*
  Copyright (c) 2020
  Swarthmore College Computer Science Department, Swarthmore PA
  J. Brody, A. Danner, M. Gagne, L. Meeden, Z. Palmer, A. Soni, M. Wehar
  Distributed as course material for Fall 2020
  CPSC 035: Data Structures and Algorithms
  https://tinyurl.com/yyr8mdoh
*/

#include <stdexcept>

#include <iostream>

using std::runtime_error;

// This file defines the methods for two classes: LinkedListNode and LinkedList.
// The LinkedListNode methods have been defined for you.  You are responsible
// for defining the LinkedList methods.

// //////// LinkedListNode /////////////////////////////////////////////////////

template <typename T>
LinkedListNode<T>::LinkedListNode(T val, LinkedListNode<T>* next) {
    this->value = val;
    this->next = next;
}

// //////// LinkedList /////////////////////////////////////////////////////////

template <typename T> LinkedList<T>::LinkedList() {
    this->head = nullptr;
    this->tail = nullptr; 
    this->size = 0; 
}

template <typename T> LinkedList<T>::~LinkedList() {
    // TODO: Not yet implemented: LinkedList::~LinkedList
    //Implement the destructor, which will delete all the nodes, from the first.
    LinkedListNode<T>* curr = this->head;
    while(this->head != nullptr) {
        curr = this->head;
        this->head = this->head->next;
        delete curr;
    }
    //start from the last node and delete what it points to
    
}

template <typename T> void LinkedList<T>::checkInvariants() {
    //Checks the number of nodes equal to the size.
    //Shape* newShape = nullptr; making a pointer variable
    LinkedListNode<T>* current = this->head;
    int count = 0; 
    while(current != nullptr){
        current = current->next; //current will become that node's next(move down chain)
        count++;
    }
    if(count != this->size){
        throw runtime_error("Not yet implemented: LinkedList::checkInvariants");
    }
}

template <typename T> int LinkedList<T>::getSize() {
    //Return size of LinkedList
    return this->size;

}

template <typename T> bool LinkedList<T>::isEmpty() {
    //Checks if LinkedList size = 0
    //if cond if size is 0, return true
    if(this->size == 0){
        return true;
    }
    else{
        return false;
    }
}

template <typename T> T LinkedList<T>::getFirst() {
    //Returns data in the first node
    if(this->size != 0){
        LinkedListNode<T>* first = this->head;
        return first->value; //returns value of what head points to
    }
   else{    //empty set case
       throw runtime_error("Not yet implemented: LinkedList::getFirst---Empty");
   }
}

template <typename T> T LinkedList<T>::getLast() {
    //Return data in the last node. 
    if(this->size != 0){
        LinkedListNode<T>* last = this->tail;
        return last->value; //returns value of what tail points to
    }
   else{    //empty set cae
       throw runtime_error("Not yet implemented: LinkedList::getFirst---Empty");
   }

}

template <typename T> T LinkedList<T>::get(int index) {
    //Take an index that returns data in that position
    if(this->size > 0){
        LinkedListNode<T>* current = this->head;
        int count = 0; 
        if(index>=0 && index < this->size){ //"index>=0" takes care of negative indices
            for(int count=0; count < index; count++){
                current = current->next; //current will become that node's next(move down chain)
            }
            return current->value;
        }
        else{   //"out-of-range-index case"
            throw runtime_error("Not yet implemented: LinkedList::get---invalid-index");
        }
    }
    //empty set case and "out-of-range-index case"
    throw runtime_error("Not yet implemented: LinkedList::get---Empty");
    //throw runtime_error("Not yet implemented: LinkedList::get");
}

template <typename T> void LinkedList<T>::insertFirst(T value) {
    //Add a new node the start of LinkedList and increase size
    //create a new node wth given data and a next where head was pointing to
    LinkedListNode<T>* newFirst = new LinkedListNode<T>(value, this->head);
    this->head = newFirst;
    this->size++;
    if(this->size==1){
        this->tail = this->head; //tail points to what head points to at first
    }
    //tail will stay where it is(at the former head)

}

template <typename T> void LinkedList<T>::insertLast(T value) {
    //Add a new node to the end of LinkedList and increase size
    //create new node
    LinkedListNode<T>* newLast = new LinkedListNode<T>(value, nullptr);
    if(this->size==0){
        this->tail = newLast; 
        this->head = newLast; //they all point to the new node formed
    }
    //cater to when set is empty and this->tail doesnt have a next
    else{
        this->tail->next = newLast;
        this->tail = newLast;
    }
    this->size++;

}

template <typename T> T LinkedList<T>::removeFirst() {
    //Remove the first node and decrease size
    if(this->size == 0){ //empty set case
        throw runtime_error("Not yet implemented: LinkedList::removeFirst---Empty List"); 
    }
    else{
        LinkedListNode<T>* formerFirst = this->head;
        LinkedListNode<T>* newFirst = formerFirst->next;
        this->head = newFirst; //this head points to second node
        if(this->size == 1){
            this->tail = this->head; //both become nullptr if single element is remoced
        }
        this->size--;
        return formerFirst->value;
        delete formerFirst;
    }

}

template <typename T> T LinkedList<T>::removeLast() {
    //Remove the first node from the end of LinkedList and decrease size
    LinkedListNode<T>* formerLast = this->tail;
    if(this->size > 1){
        LinkedListNode<T>* current = this->head;
        for(int count=0; count < this->size-2; count++){
            current = current->next; //current will become that node's next(move down chain)
        }
        current->next = nullptr;
        this->tail = current; //current points to second last, its next becomes nullptr
    }
    else if(this->size == 1) { //single element set
        this->tail = nullptr;
        this->head = nullptr;
    }  
    else if(this->size == 0){ //empty set case
        throw runtime_error("Not yet implemented: LinkedList::removeLast---Empty List"); 
    }
    this->size--;
    return formerLast->value; 
    delete formerLast; 
    

}
